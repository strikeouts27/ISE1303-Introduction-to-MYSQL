-- INT VARCHAR(45) ENUM VARCHAR DECIMAL ENUM NUMOFPLAYERS, PlayMinutes
INSERT INTO `boardgames`.`boardgames`
(`BoardgamesID`, 
`Publisher`,
`BoardgameType`,
`Title`,
`Price`,
`Rating`,
`NumberOfPlayers`,
`PlayMinutes`)
VALUES
(10,
'Evil Hat Productions',
'CombatGames', 
'TheDresdenFilesCooperativeCardGame',
60.00,
'B',
4,
60);
